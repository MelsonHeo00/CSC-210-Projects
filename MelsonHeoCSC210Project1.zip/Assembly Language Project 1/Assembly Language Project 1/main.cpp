#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>

#define _CRT_SECURE_NO_DEPRECATE
#pragma warning (disable : 4996)

#define byte unsigned char
#define word unsigned short

byte mem[0x100000];

using namespace std;
using namespace std::this_thread;
using namespace std::chrono_literals;
using std::chrono::system_clock;

// Physical registers
byte AL, BL, CL, DL, AH, BH, CH, DH;
word AX, BX, CX, DX;
word IP, FLAGS;
word CS, DS, ES, FS, SP, BP, SI, DI, SS;
byte opcode = 0x00;
byte code[0x10000];
byte data[0x10000];
byte stack[0x10000];

int main() {

    cout << "--This is an emulator's x86. This code will provide you the readings of assembly--" << endl;

    // size
    int size = 0x100000;
    unsigned char buffer[100000];

    // File Implementation
    short s;
    cout << "Note: You have to change the file name in every implementation" << "\n\n";
    FILE* file = fopen("C://emu8086//MyBuild//Hello World.com", "rb"); // Change the file name
    if (!file) {
        sleep_for(10ns);
        sleep_until(system_clock::now() + 1s);
        cout << "File could not open, try to use a different file." << endl;
    }
    fread(&s, 1, 0x1000000, file);
    fclose(file); // this will close the file
    sleep_for(10ns);
    sleep_until(system_clock::now() + 2s);
    cout << "The file is now being processed..." << endl;

    // File Execution
    sleep_for(10ns);
    sleep_until(system_clock::now() + 5s);
    cout << "Now the code will read your file ouput..." << endl;
    

    // memory layout
    IP = 0x000;
    FLAGS = 0x00000000;
    SP = 0xFFFE;

    while (1) {
        opcode = mem[IP++];
        switch (opcode) {

            // NOP Instruction
            // Definition: a one byte instruction that takes up space in the instruction stream but performs no operation
        case 0x90:
            break;

            // INT Instruction
            // Definition: an instruction that declares an interruption if there is any
        case 0xCD:
            opcode = mem[IP++];
            if (opcode == 0x20)
            {
                return 0;
            }

        default:
            switch (opcode) {

            // Increments
            case 0xFE:
                opcode = mem[IP++];
                switch (opcode) {

                //Increment 8-bit Register
                case 0xC0:
                    AL++;
                    AX = AL + AH;
                    break;
                case 0xC1:
                    CL++;
                    CX = CL + CH;
                    break;
                case 0xC2:
                    DL++;
                    DX = DL + DH;
                    break;
                case 0xC3:
                    BL++;
                    BX = BL + BH;
                    break;
                case 0xC4:
                    AH++;
                    AX = AL + AH;
                    break;
                case 0xC5:
                    CH++;
                    CX = CL + CH;
                    break;
                case 0xC6:
                    DH++;
                    DX = DL + DH;
                    break;
                case 0xC7:
                    BH++;
                    BX = BL + BX;
                    break;

                //Decrement 8-bit Register

                case 0xC8:
                    AL--;
                    AX = AL + AH;
                    break;
                case 0xC9:
                    CL--;
                    CX = CL + CH;
                    break;
                case 0xCA:
                    DL--;
                    DX = DL + DH;
                    break;
                case 0xCB:
                    BL--;
                    BX = BL + BX;
                    break;
                case 0xCC:
                    AH--;
                    AX = AL + AH;
                    break;
                case 0xCD:
                    CH--;
                    CX = CL + CH;
                    break;
                case 0xCE:
                    DH--;
                    DX = DL + DH;
                    break;
                case 0xCF:
                    BH--;
                    BX = BL + BX;
                    break;
                }
                break;

            //Increments for 16-Bit Register

            case 0x40:
                AX++;
                break;
            case 0x41:
                CX++;
                break;
            case 0x42:
                DX++;
                break;
            case 0x43:
                BX++;
                break;
            case 0x44:
                SP++;
                break;
            case 0x45:
                BP++;
                break;
            case 0x46:
                SI++;
                break;
            case 0x47:
                DI++;
                break;

                //Decrements for 16-Bit Register
            case 0x48:
                AX--;
                break;
            case 0x49:
                CX--;
                break;
            case 0x4A:
                DX--;
                break;
            case 0x4B:
                BX--;
                break;
            case 0x4C:
                SP--;
                break;
            case 0x4D:
                BP--;
                break;
            case 0x4E:
                SI--;
                break;
            case 0x4F:
                DI--;
                break;

                // MOV Instruction
                // Definition: an instruction that copies the second operand to the first operand
            case 0xB0:
                opcode = mem[IP++];
                AL = opcode;
                AX = AL + AH;
                break;
            case 0xB1:
                opcode = mem[IP++];
                CL = opcode;
                CX = CL + CH;
                break;
            case 0xB2:
                opcode = mem[IP++];
                DL = opcode;
                DX = DL + DH;
                break;
            case 0xB3:
                opcode = mem[IP++];
                BL = opcode;
                BX = BL + BH;
                break;
            case 0xB5:
                opcode = mem[IP++];
                AX = opcode;
                AX = AL + AH;
                break;
            case 0xB6:
                opcode = mem[IP++];
                CX = opcode;
                CX = CL + CH;
                break;
            case 0xB7:
                opcode = mem[IP++];
                DX = opcode;
                DX = DL + DH;
                break;
            case 0xB8:
                opcode = mem[IP++];
                BX = opcode;
                BX = BL + BH;
                break;

                // ADD Instruction
                // Definition: an instruction that adds the two operands together

            case 0x00:
                opcode = mem[IP++];
                switch (opcode) {

                    // AL
                case 0xC0:
                    AL = AL + AL;
                    AX = AL + AH;
                    break;
                case 0xC1:
                    AL = AL + CL;
                    AX = AL + AH;
                    break;
                case 0xC2:
                    AL = AL + DL;
                    AX = AL + AH;
                    break;
                case 0xC3:
                    AL = AL + BL;
                    AX = AL + AH;
                    break;
                case 0xC4:
                    AL = AL + AH;
                    AX = AL + AH;
                    break;
                case 0xC5:
                    AL = AL + CH;
                    AX = AL + AH;
                    break;
                case 0xC6:
                    AL = AL + DH;
                    AX = AL + AH;
                    break;
                case 0xC7:
                    AL = AL + BH;
                    AX = AL + AH;
                    break;

                    // CL
                case 0xC8:
                    CL = CL + AL;
                    CX = CL + CH;
                    break;
                case 0xC9:
                    CL = CL + CL;
                    CX = CL + CH;
                    break;
                case 0xCA:
                    CL = CL + DL;
                    CX = CL + CH;
                    break;
                case 0xCB:
                    CL = CL + BL;
                    CX = CL + CH;
                    break;
                case 0xCC:
                    CL = CL + AH;
                    CX = CL + CH;
                    break;
                case 0xCD:
                    CL = CL + CH;
                    CX = CL + CH;
                    break;
                case 0xCE:
                    CL = CL + DH;
                    CX = CL + CH;
                    break;
                case 0xCF:
                    CL = CL + BH;
                    CX = CL + CH;
                    break;

                    // DL
                case 0xD0:
                    DL = DL + AL;
                    DX = DL + DH;
                    break;
                case 0xD1:
                    DL = DL + CL;
                    DX = DL + CH;
                    break;
                case 0xD2:
                    DL = DL + DL;
                    DX = DL + DH;
                    break;
                case 0xD3:
                    DL = DL + BL;
                    CX = DL + DH;
                    break;
                case 0xD4:
                    DL = DL + AH;
                    DX = DL + DH;
                    break;
                case 0xD5:
                    DL = DL + CH;
                    DX = DL + DH;
                    break;
                case 0xD6:
                    DL = DL + DH;
                    DX = DL + DH;
                    break;
                case 0xD7:
                    DL = DL + BH;
                    DX = DL + DH;
                    break;

                    // BL
                case 0xD8:
                    BL = BL + AL;
                    BX = BL + BH;
                    break;
                case 0xD9:
                    BL = BL + CL;
                    BX = BL + BH;
                    break;
                case 0xDA:
                    BL = BL + DL;
                    BX = BL + BH;
                    break;
                case 0xDB:
                    BL = BL + BL;
                    BX = BL + BH;
                    break;
                case 0xDC:
                    BL = BL + AH;
                    BX = BL + BH;
                    break;
                case 0xDD:
                    BL = BL + CH;
                    BX = BL + BH;
                    break;
                case 0xDE:
                    BL = BL + DH;
                    BX = BL + BH;
                    break;
                case 0xDF:
                    BL = BL + BH;
                    BX = BL + BH;
                    break;

                    // AH
                case 0xE0:
                    AH = AH + AL;
                    AX = AL + AH;
                    break;
                case 0xE1:
                    AH = AH + CL;
                    AX = AL + AH;
                    break;
                case 0xE2:
                    AH = AH + DL;
                    AX = AL + AH;
                    break;
                case 0xE3:
                    AH = AH + BL;
                    AX = AL + AH;
                    break;
                case 0xE4:
                    AH = AH + AH;
                    AX = AL + AH;
                    break;
                case 0xE5:
                    AH = AH + CH;
                    AX = AL + AH;
                    break;
                case 0xE6:
                    AH = AH + DH;
                    AX = AL + AH;
                    break;
                case 0xE7:
                    AH = AH + BH;
                    AX = AL + AH;
                    break;

                    // CH
                case 0xE8:
                    CH = CH + AL;
                    CX = CL + CH;
                    break;
                case 0xE9:
                    CH = CH + CL;
                    CX = CL + CH;
                    break;
                case 0xEA:
                    CH = CH + DL;
                    CX = CL + CH;
                    break;
                case 0xEB:
                    CH = CH + BL;
                    CX = CL + CH;
                    break;
                case 0xEC:
                    CH = CH + AH;
                    CX = CL + CH;
                    break;
                case 0xED:
                    CH = CH + CH;
                    CX = CL + CH;
                    break;
                case 0xEE:
                    CH = CH + DH;
                    CX = CL + CH;
                    break;
                case 0xEF:
                    CH = CH + BH;
                    CX = CL + CH;
                    break;

                    // DH
                case 0xF0:
                    DH = DH + AL;
                    DX = DL + DH;
                    break;
                case 0xF1:
                    DH = DH + CL;
                    DX = DL + CH;
                    break;
                case 0xF2:
                    DH = DH + DL;
                    DX = DL + DH;
                    break;
                case 0xF3:
                    DH = DH + BL;
                    CX = DL + DH;
                    break;
                case 0xF4:
                    DH = DH + AH;
                    DX = DL + DH;
                    break;
                case 0xF5:
                    DH = DH + CH;
                    DX = DL + DH;
                    break;
                case 0xF6:
                    DH = DH + DH;
                    DX = DL + DH;
                    break;
                case 0xF7:
                    DH = DH + BH;
                    DX = DL + DH;
                    break;

                    // BH
                case 0xF8:
                    BH = BH + AL;
                    BX = BL + BH;
                    break;
                case 0xF9:
                    BH = BH + CL;
                    BX = BL + BH;
                    break;
                case 0xFA:
                    BH = BH + DL;
                    BX = BL + BH;
                    break;
                case 0xFB:
                    BH = BH + BL;
                    BX = BL + BH;
                    break;
                case 0xFC:
                    BH = BH + AH;
                    BX = BL + BH;
                    break;
                case 0xFD:
                    BH = BH + CH;
                    BX = BL + BH;
                    break;
                case 0xFE:
                    BH = BH + DH;
                    BX = BL + BH;
                    break;
                case 0xFF:
                    BH = BH + BH;
                    BX = BL + BH;
                    break;
                }
                break;


                // SUB Instruction
                // Defintion: an instruction that subtracts the second operand from the first operand
            case 0x2A:
                opcode = mem[IP++];
                switch (opcode) {

                    // AL
                case 0xC0:
                    AL = AL - AL;
                    AX = AL - AH;
                    break;
                case 0xC1:
                    AL = AL - CL;
                    AX = AL - AH;
                    break;
                case 0xC2:
                    AL = AL - DL;
                    AX = AL - AH;
                    break;
                case 0xC3:
                    AL = AL - BL;
                    AX = AL - AH;
                    break;
                case 0xC4:
                    AL = AL - AH;
                    AX = AL - AH;
                    break;
                case 0xC5:
                    AL = AL - CH;
                    AX = AL = AH;
                    break;
                case 0xC6:
                    AL = AL - DH;
                    AX = AL - AH;
                    break;
                case 0xC7:
                    AL = AL - BH;
                    AX = AL - AH;
                    break;

                    // CL
                case 0xC8:
                    CL = CL - AL;
                    CX = CL - CH;
                    break;
                case 0xC9:
                    CL = CL - CL;
                    CX = CL - CH;
                    break;
                case 0xCA:
                    CL = CL - DL;
                    CX = CL - CH;
                    break;
                case 0xCB:
                    CL = CL - BL;
                    CX = CL - CH;
                    break;
                case 0xCC:
                    CL = CL - AH;
                    CX = CL - CH;
                    break;
                case 0xCD:
                    CL = CL - CH;
                    CX = CL - CH;
                    break;
                case 0xCE:
                    CL = CL - DH;
                    CX = CL - CH;
                    break;
                case 0xCF:
                    CL = CL - BH;
                    CX = CL - CH;
                    break;

                    // DL
                case 0xD0:
                    DL = DL - AL;
                    DX = DL - DH;
                    break;
                case 0xD1:
                    DL = DL - CL;
                    DX = DL - CH;
                    break;
                case 0xD2:
                    DL = DL - DL;
                    DX = DL - DH;
                    break;
                case 0xD3:
                    DL = DL - BL;
                    CX = DL - DH;
                    break;
                case 0xD4:
                    DL = DL - AH;
                    DX = DL - DH;
                    break;
                case 0xD5:
                    DL = DL - CH;
                    DX = DL - DH;
                    break;
                case 0xD6:
                    DL = DL - DH;
                    DX = DL - DH;
                    break;
                case 0xD7:
                    DL = DL - BH;
                    DX = DL - DH;
                    break;

                    // BL
                case 0xD8:
                    BL = BL - AL;
                    BX = BL - BH;
                    break;
                case 0xD9:
                    BL = BL - CL;
                    BX = BL - BH;
                    break;
                case 0xDA:
                    BL = BL - DL;
                    BX = BL - BH;
                    break;
                case 0xDB:
                    BL = BL - BL;
                    BX = BL - BH;
                    break;
                case 0xDC:
                    BL = BL - AH;
                    BX = BL - BH;
                    break;
                case 0xDD:
                    BL = BL - CH;
                    BX = BL - BH;
                    break;
                case 0xDE:
                    BL = BL - DH;
                    BX = BL - BH;
                    break;
                case 0xDF:
                    BL = BL - BH;
                    BX = BL - BH;
                    break;

                    // AH
                case 0xE0:
                    AH = AH - AL;
                    AX = AL - AH;
                    break;
                case 0xE1:
                    AH = AH - CL;
                    AX = AL - AH;
                    break;
                case 0xE2:
                    AH = AH - DL;
                    AX = AL - AH;
                    break;
                case 0xE3:
                    AH = AH - BL;
                    AX = AL - AH;
                    break;
                case 0xE4:
                    AH = AH - AH;
                    AX = AL - AH;
                    break;
                case 0xE5:
                    AH = AH - CH;
                    AX = AL - AH;
                    break;
                case 0xE6:
                    AH = AH - DH;
                    AX = AL - AH;
                    break;
                case 0xE7:
                    AH = AH - BH;
                    AX = AL - AH;
                    break;

                    // CH
                case 0xE8:
                    CH = CH - AL;
                    CX = CL - CH;
                    break;
                case 0xE9:
                    CH = CH - CL;
                    CX = CL - CH;
                    break;
                case 0xEA:
                    CH = CH - DL;
                    CX = CL - CH;
                    break;
                case 0xEB:
                    CH = CH - BL;
                    CX = CL - CH;
                    break;
                case 0xEC:
                    CH = CH - AH;
                    CX = CL - CH;
                    break;
                case 0xED:
                    CH = CH - CH;
                    CX = CL - CH;
                    break;
                case 0xEE:
                    CH = CH - DH;
                    CX = CL - CH;
                    break;
                case 0xEF:
                    CH = CH - BH;
                    CX = CL - CH;
                    break;

                    // DH
                case 0xF0:
                    DH = DH - AL;
                    DX = DL - DH;
                    break;
                case 0xF1:
                    DH = DH - CL;
                    DX = DL - CH;
                    break;
                case 0xF2:
                    DH = DH - DL;
                    DX = DL - DH;
                    break;
                case 0xF3:
                    DH = DH - BL;
                    CX = DL - DH;
                    break;
                case 0xF4:
                    DH = DH - AH;
                    DX = DL - DH;
                    break;
                case 0xF5:
                    DH = DH - CH;
                    DX = DL - DH;
                    break;
                case 0xF6:
                    DH = DH - DH;
                    DX = DL - DH;
                    break;
                case 0xF7:
                    DH = DH = BH;
                    DX = DL - DH;
                    break;

                    // BH
                case 0xF8:
                    BH = BH - AL;
                    BX = BL - BH;
                    break;
                case 0xF9:
                    BH = BH - CL;
                    BX = BL - BH;
                    break;
                case 0xFA:
                    BH = BH - DL;
                    BX = BL - BH;
                    break;
                case 0xFB:
                    BH = BH - BL;
                    BX = BL - BH;
                    break;
                case 0xFC:
                    BH = BH - AH;
                    BX = BL - BH;
                    break;
                case 0xFD:
                    BH = BH - CH;
                    BX = BL - BH;
                    break;
                case 0xFE:
                    BH = BH - DH;
                    BX = BL - BH;
                    break;
                case 0xFF:
                    BH = BH - BH;
                    BX = BL - BH;
                    break;
                }
                break;

            }
            break;
        }
        break;
    }

        // Output of the code
        printf("\n\nIP: %d %10s OPCODE: %02X\n", IP, " ", opcode);
        printf("AL = %02X \t CL = %02X \t DL = %02X \t BL = %02X \n", AL, CL, DL, BL);
        printf("AH = %02X \t CH = %02X \t DH = %02X \t BH = %02X \n", AH, CH, DH, BH);
        printf("AX = %04X \t CX = %04X \t DX = %04X \t BX = %04X \n", AX, CX, DX, BX);
        printf("SP = %04X \t BP = %04X \t SI = %04X \t DI = %04X \n", SP, BP, SI, DI);
        printf("FLAGS: %03X \t", FLAGS);
        cout << "\n\n\n";
        cout << "Output of the code: " << file << endl;
        cout << "Termination of the program.";
        return 0;
}