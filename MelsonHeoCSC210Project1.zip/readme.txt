This is Melson Heo's readme.txt. These will include all of the comments and process within making an emulator.

Main Task: Making an emulator x86.
- Knowing all of the registers
- Providing example codes for the emulator to run

Example Code 1: Hello World
Example Code 2: Addition and Subtraction
Example Code 3: Letters
Example Code 4: Compare Numbers
Example Code 5: Hex

During int main():
	- Size Declaration
	- Declaration of all of the physical registers regarding 8 bits, 16 bits, and FLAGS registers
	- Instruction Pointer
	- File Implementation
		- Used fopen to get the file to open
		- Used fread to read the file
		- Fclose will close the file
	- File execution
		- A While Loop
		- NOP: a function that does no operations
		- MOV: a function that moves
		- INC: increments
		- DEC: decrements
		- ADD: a function that adds two operands
		- SUB: a function that subtracts two operands
	- Output of the code

Instructions:
The file name has be changed for any implementation of the code. If the file name is incorrect, the file will not be processed.
Convert your file path from "" to "//".
Example: ("C://emu8086//MyBuild//Hello World.com", "rb") (you do not need to change the rb)

Improvements: I could not get my code to run properly. During the while loop, it would run non stop and go on an infinite loop.
Therefore, I could not get the correct output in time. The output would only be the default and the IP will only show a few numbers at a time.
If I spent more time figuring out with the while loop, I could have figured out how to output the code more properly and better instructions.

Regards, Melson Heo.