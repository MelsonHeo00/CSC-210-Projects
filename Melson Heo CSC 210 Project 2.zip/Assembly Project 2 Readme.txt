This is Melson Heo's readme.txt. These will include all of the comments and process within making a calendar.

This project was to deisgn a calendar based on using assembly language.

What I did:
- Made classes for all of the months of 2021
- Gave the user options to choose which month to display
- Set up conditions for each input
- Formatted each month

Improvements:
- Did not add any if statements, therefore it would only output decemeber as a result
- Only has one month working, need to work on comparison
